LIZ & MPUMI'S TREATS — CLOUDFLARE DIRECT UPLOAD

This is a plain static website for Cloudflare's Upload and deploy screen.
There is intentionally NO wrangler.jsonc file.

Upload the files in this folder (or use the ZIP) in Cloudflare Workers > Upload and deploy.
Do not add a wrangler config file to the direct-upload project.
