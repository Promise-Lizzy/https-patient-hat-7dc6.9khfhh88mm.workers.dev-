let cart=[];
function addItem(name,price){cart.push({name,price});renderCart();document.getElementById('sweetbox').scrollIntoView({behavior:'smooth',block:'center'});}
function removeItem(i){cart.splice(i,1);renderCart();}
function renderCart(){
 const count=document.getElementById('cartCount'); if(count) count.textContent=cart.length;
 const box=document.getElementById('cartItems');
 const total=cart.reduce((s,x)=>s+x.price,0);
 document.getElementById('cartTotal').textContent=total;
 if(!cart.length){box.innerHTML='<p>Your Sweet Box is empty. This is your sign to add something. 👀💕</p>';return;}
 box.innerHTML=cart.map((x,i)=>`<div class="cart-row"><span>${x.name}</span><b>R${x.price} <button type="button" onclick="removeItem(${i})">×</button></b></div>`).join('')+`<p style="margin:12px 0 0;font-weight:800">Ready? Scroll up and choose “Order Now” 💌</p>`;
}
document.getElementById('orderForm').addEventListener('submit',function(e){
 e.preventDefault();
 const name=document.getElementById('name').value.trim();
 const date=document.getElementById('date').value;
 const method=document.getElementById('method').value;
 const notes=document.getElementById('notes').value.trim();
 const items=cart.length?cart.map(x=>`${x.name} — R${x.price}`).join('\n'):'Please help me choose my treats';
 const message=`SANIBONANI BO CHOMMIE! 👋🏽💕\n\nHi Liz & Mpumi’s Treats!\nName: ${name}\nOrder date: ${date}\nCollection/Delivery: ${method}\n\nSweet Box:\n${items}\n\nFlavours / toppings / extra notes:\n${notes}\n\nPlease confirm availability, payment/deposit and collection/delivery details. Thank you! 🧁💕`;
 const encoded=encodeURIComponent(message);
 window.open('https://wa.me/27846536220?text='+encoded,'_blank');
 setTimeout(()=>window.open('https://wa.me/27763713214?text='+encoded,'_blank'),500);
});
renderCart();

const menuToggle=document.getElementById('menuToggle');
const mainNav=document.querySelector('.nav');
if(menuToggle && mainNav){
  menuToggle.addEventListener('click',()=>{
    const open=mainNav.classList.toggle('nav-open');
    menuToggle.setAttribute('aria-expanded',String(open));
  });
  mainNav.querySelectorAll('a').forEach(link=>{
    link.addEventListener('click',()=>{
      mainNav.classList.remove('nav-open');
      menuToggle.setAttribute('aria-expanded','false');
    });
  });
}
